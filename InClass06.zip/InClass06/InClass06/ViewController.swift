//
//  ViewController.swift
//  InClass06
//
//  Created by Yang, Marvin on 2/20/19.
//  Copyright © 2019 Yang, Marvin. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    
    @IBOutlet var tableView: UITableView!
    
    var users: [User]?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        
        let cellNib = UINib(nibName: "CustomTableViewCell", bundle: nil)
        tableView.register(cellNib, forCellReuseIdentifier: "MyCell")
        
        users = DataInfo.users
    }
    
    
    @IBAction func sortButtonClicked(_ sender: Any) {
        
        let alert = UIAlertController(title: "Sort By", message: "Pick option to sort users by", preferredStyle: .actionSheet)
        alert.addAction(UIAlertAction(title: "Name", style: .default, handler: {
            (ACTION :UIAlertAction!)in
            self.users = self.users?.sorted(by: {$0.name! < $1.name!})
            self.tableView.reloadData()
        }))
        alert.addAction(UIAlertAction(title: "Age", style: .default, handler: {
            (ACTION :UIAlertAction!)in
            self.users = self.users?.sorted(by: {$0.age! < $1.age!})
            self.tableView.reloadData()
        }))
        alert.addAction(UIAlertAction(title: "State", style: .default, handler: {
            (ACTION :UIAlertAction!)in
            self.users = self.users?.sorted(by: {$0.state! < $1.state!})
            self.tableView.reloadData()
        }))
        alert.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: nil))
        
        self.present(alert, animated: true, completion: nil)
        
    }
    
    @IBAction func filterButtonClicked(_ sender: Any) {
        
        let alert = UIAlertController(title: "Filter By", message: "Pick option to filter users by", preferredStyle: .actionSheet)
        alert.addAction(UIAlertAction(title: "Gender : Female", style: .default, handler: {
            (ACTION :UIAlertAction!)in
            self.users = []
            for user in DataInfo.users {
                if user.gender! == "Female" {
                    self.users?.append(user)
                }
            }
            
            self.tableView.reloadData()
        }))
        alert.addAction(UIAlertAction(title: "Gender : Male", style: .default, handler: {
            (ACTION :UIAlertAction!)in
            self.users = []
            for user in DataInfo.users {
                if user.gender! == "Male" {
                    self.users?.append(user)
                }
            }
            self.tableView.reloadData()
        }))
        alert.addAction(UIAlertAction(title: "Show All", style: .default, handler: {
            (ACTION :UIAlertAction!)in
            self.users = DataInfo.users
            self.tableView.reloadData()
        }))
        alert.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: nil))
        
        self.present(alert, animated: true, completion: nil)
        
    }
    


}

extension ViewController: UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return DataInfo.users.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "MyCell", for: indexPath) as! CustomTableViewCell
        let user = self.users![indexPath.row]
        
        cell.nameLabel.text = user.name
        cell.stateLabel.text = user.state
        cell.ageLabel.text = String(user.age!)
        cell.groupLabel.text = user.group
        
        switch user.gender {
        case "Male":
            cell.genderImage.image = UIImage(named: "avatar_male")
        case "Female":
            cell.genderImage.image = UIImage(named: "avatar_female")
        default:
            print("Error in switch user.gender")
        }
        
        return cell
        
    }
    
    
    
    
}

extension ViewController: UITableViewDelegate {
    
}
