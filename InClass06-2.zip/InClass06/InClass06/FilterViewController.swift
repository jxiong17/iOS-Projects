//
//  FilterViewController.swift
//  InClass06
//
//  Created by Xiong, Jeff on 2/25/19.
//  Copyright © 2019 Yang, Marvin. All rights reserved.
//

import UIKit

class FilterViewController: UIViewController {

    var listofType: [String]?
    var selected: String?
    @IBOutlet weak var tableView: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        //print(listofType!)
        
        //change nav title
        switch type {
        case 0:
            self.navigationItem.title = "Filter By State"
        case 1:
            self.navigationItem.title = "Filter By Group"
        case 2:
            self.navigationItem.title = "Filter By Gender"
        default:
            print("Error in nav Title")
        }
        
    }
    
    
    //prepare to send object to Viewcontrol
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        
        print("This is the prepare for segue in filter viewcontroler")

        let destinationProfile = segue.destination as! ViewController
        destinationProfile.selected = selected
        
    }
        
        

}


extension FilterViewController: UITableViewDataSource {
    //numbero of rows
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return listofType!.count
        
    }
    
    //design and populate cell with array
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "myCell", for: indexPath)
        let list = listofType![indexPath.row]
        
        cell.textLabel?.text = list
        
        return cell
    }
    
    
    
}


extension FilterViewController: UITableViewDelegate {
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        print(listofType![indexPath.row] + " is selected")
        
        selected = listofType![indexPath.row]
        
        //manually proferome unwinded segue
        self.performSegue(withIdentifier: "FilterToUsers", sender: self)
        
        
    }
}
