//
//  ViewController.swift
//  InClass06
//
//  Created by Yang, Marvin on 2/20/19.
//  Copyright © 2019 Yang, Marvin. All rights reserved.
//

import UIKit

var type: Int?

class ViewController: UIViewController {
    
    
    @IBOutlet var tableView: UITableView!
    
    var users: [User]?
    var arry = [String]()
    var list: [String]?
    var selected: String?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        
        let cellNib = UINib(nibName: "CustomTableViewCell", bundle: nil)
        tableView.register(cellNib, forCellReuseIdentifier: "MyCell")
        
        users = DataInfo.users
       
    }
    
    
    @IBAction func sortButtonClicked(_ sender: Any) {
        
        let alert = UIAlertController(title: "Sort By", message: "Pick option to sort users by", preferredStyle: .actionSheet)
        alert.addAction(UIAlertAction(title: "Name", style: .default, handler: {
            (ACTION :UIAlertAction!)in
            self.users = self.users?.sorted(by: {$0.name! < $1.name!})
            self.tableView.reloadData()
        }))
        alert.addAction(UIAlertAction(title: "Age", style: .default, handler: {
            (ACTION :UIAlertAction!)in
            self.users = self.users?.sorted(by: {$0.age! < $1.age!})
            self.tableView.reloadData()
        }))
        alert.addAction(UIAlertAction(title: "State", style: .default, handler: {
            (ACTION :UIAlertAction!)in
            self.users = self.users?.sorted(by: {$0.state! < $1.state!})
            self.tableView.reloadData()
        }))
        alert.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: nil))
        
        self.present(alert, animated: true, completion: nil)
        
    }
    
    @IBAction func filterButtonClicked(_ sender: Any) {
        
        let alert = UIAlertController(title: "Filter By", message: "Pick option to filter users by", preferredStyle: .actionSheet)
        alert.addAction(UIAlertAction(title: "State", style: .default, handler: {
            (ACTION :UIAlertAction!)in

            
            //assign type
            type = 0
            
            //create list of states
            for user in DataInfo.users{
                
                self.arry.append(user.state!)
            }
            
            //sort and remove duplicates
            self.list = Array(Set(self.arry)).sorted()
            
            //send data to filter view
            self.performSegue(withIdentifier: "UsersToFilter", sender: self)

        }))
        alert.addAction(UIAlertAction(title: "Group", style: .default, handler: {
            (ACTION :UIAlertAction!)in
            
            //assign type
            type = 1
            
            print("This is in the alerts \(type!)")
            
            self.list = ["Family", "Friend", "Work"]
            
            //send data to filter view
            self.performSegue(withIdentifier: "UsersToFilter", sender: self)

            
        }))
        alert.addAction(UIAlertAction(title: "Gender", style: .default, handler: {
        (ACTION :UIAlertAction!)in
        
            //assign type
            type = 2
            
            print("This is in the alerts \(type!)")
            
            self.list = ["Female", "Male"]
            
            //send data to filter view
            self.performSegue(withIdentifier: "UsersToFilter", sender: self)

        
        }))
        
        
        alert.addAction(UIAlertAction(title: "Show All", style: .default, handler: {
            (ACTION :UIAlertAction!)in
            self.users = DataInfo.users
            self.tableView.reloadData()
        }))
        alert.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: nil))
        
        self.present(alert, animated: true, completion: nil)
        
    }
    
    
    //prepare to send object contact selected to detials
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        print("prepare was ran in user view")
        
        if segue.identifier == "UsersToFilter" {
            
            let destinationProfile = segue.destination as! FilterViewController
            destinationProfile.listofType = list
            
        }
    }
    
    //first unwind adding new contact
    @IBAction func myUnwindAction(unwindSegue: UIStoryboardSegue){
        
        print("my unwind ran in view controller and this is the data passed \(selected!)")
        
        //determind if user picked state, group, or gender and update the array
        switch type! {
        case 0:
            self.users = []
            for user in DataInfo.users {
                if user.state! == selected! {
                self.users?.append(user)
                }
            }
        case 1:
            self.users = []
            for user in DataInfo.users {
                if user.group! == selected! {
                    self.users?.append(user)
                }
            }
        case 2:
            self.users = []
            for user in DataInfo.users {
                if user.gender! == selected! {
                    self.users?.append(user)
                }
            }
            
        default:
            print("Error in myUnwind")
        }

        
        self.tableView.reloadData()
        
    }


}

extension ViewController: UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return users!.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "MyCell", for: indexPath) as! CustomTableViewCell
        let user = self.users![indexPath.row]
        
        cell.nameLabel.text = user.name
        cell.stateLabel.text = user.state
        cell.ageLabel.text = String(user.age!)
        cell.groupLabel.text = user.group
        
        switch user.gender {
        case "Male":
            cell.genderImage.image = UIImage(named: "avatar_male")
        case "Female":
            cell.genderImage.image = UIImage(named: "avatar_female")
        default:
            print("Error in switch user.gender")
        }
        
        return cell
        
    }
    
    
    
    
}

extension ViewController: UITableViewDelegate {

}
