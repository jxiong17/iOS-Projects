//
//  ViewController.swift
//  Homework_01
//
//  Created by Yang, Marvin on 1/28/19.
//  Copyright © 2019 Yang, Marvin. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var billTotalTextBox: UITextField!
    @IBOutlet weak var tipSegmentedControl: UISegmentedControl!
    @IBOutlet weak var customTipSlider: UISlider!
    @IBOutlet weak var customTipLabel: UILabel!
    @IBOutlet weak var tipLabel: UILabel!
    @IBOutlet weak var totalLabel: UILabel!
    
    var tipPercentage: Int = 25
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    private func updateTipAndTotal() {
        if (billTotalTextBox.text!.isEmpty || Double(billTotalTextBox.text!) == nil) {
            tipLabel.text = "0.00"
            totalLabel.text = "0.00"
            return
        }
        
        var multiplier: Double
        
        switch tipSegmentedControl.selectedSegmentIndex {
        case 0:
            multiplier = 0.1
        case 1:
            multiplier = 0.15
        case 2:
            multiplier = 0.18
        case 3:
            multiplier = Double(tipPercentage) * 0.01
        default:
            print("Error")
            tipLabel.text = "0.00"
            totalLabel.text = "0.00"
            return
        }
        
        let tipAmount = Double(billTotalTextBox.text!)! * multiplier
        tipLabel.text = String(Double(round(100*tipAmount)/100))
        
        let totalAmount = Double(billTotalTextBox.text!)! + tipAmount
        totalLabel.text = String(Double(round(100*totalAmount)/100))
        
    }
    
    
    @IBAction func billTotalTextFieldEditing(_ sender: Any) {
        
        updateTipAndTotal()
        
    }
    
    @IBAction func segmentedTipControl(_ sender: UISegmentedControl) {
        
        updateTipAndTotal()
        
    }
    
    @IBAction func customTipSlider(_ sender: UISlider) {
        
        tipPercentage = Int(sender.value)
        customTipLabel.text = String(tipPercentage) + "%"
        
        updateTipAndTotal()
        
    }
    
    @IBAction func clearButton(_ sender: Any) {
        
        tipLabel.text = "0.00"
        totalLabel.text = "0.00"
        billTotalTextBox.text = ""
        customTipLabel.text = "25%"
        tipSegmentedControl.selectedSegmentIndex = 0
        customTipSlider.value = 25.0
        
    }
    
}
