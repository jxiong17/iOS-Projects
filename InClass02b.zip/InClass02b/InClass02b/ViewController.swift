//
//  ViewController.swift
//  InClass02b
//
//  Created by Xiong, Jeff on 1/23/19.
//  Copyright © 2019 Xiong, Jeff. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    
    @IBOutlet weak var resultLabel: UILabel!
    @IBOutlet weak var firstTextNum: UITextField!
    @IBOutlet weak var secondTextNum: UITextField!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    
    
    @IBAction func addButton(_ sender: Any) {
        
        var num1:Double
        var num2:Double
        
        
        if Double(firstTextNum.text!) == nil || Double(secondTextNum.text!) == nil {
            
            let alert = UIAlertController(title: "Invalid Number", message: "Please enter a number!", preferredStyle: .alert)
            
            let action = UIAlertAction(title: "Cancel", style: .default, handler: nil)
            
            alert.addAction(action)
            
            present(alert, animated: true, completion: nil)
        }
            
        else if firstTextNum.text!.isEmpty || secondTextNum.text!.isEmpty{
            
            let alert = UIAlertController(title: "Number Needed", message: "Please enter a number!", preferredStyle: .alert)
            
            let action = UIAlertAction(title: "Cancel", style: .default, handler: nil)
            
            alert.addAction(action)
            
            present(alert, animated: true, completion: nil)
        }
        else {
            
            print("in this method")
            num1 = Double(firstTextNum.text!)!
            num2 = Double(secondTextNum.text!)!
            
            let sum = Double(num1 + num2)
            
            resultLabel.text = "Result : \(sum)"
        }
        
    }
    
    
    
    @IBAction func subtractButton(_ sender: Any) {
        
        var num1:Double
        var num2:Double
        
        if Double(firstTextNum.text!) == nil || Double(secondTextNum.text!) == nil {
            
            let alert = UIAlertController(title: "Invalid Number", message: "Please enter a number!", preferredStyle: .alert)
            
            let action = UIAlertAction(title: "Cancel", style: .default, handler: nil)
            
            alert.addAction(action)
            
            present(alert, animated: true, completion: nil)
        }
        
        else if firstTextNum.text!.isEmpty || secondTextNum.text!.isEmpty{
            
            let alert = UIAlertController(title: "Number Needed", message: "Please enter a number!", preferredStyle: .alert)
            
            let action = UIAlertAction(title: "Cancel", style: .default, handler: nil)
            
            alert.addAction(action)
            
            present(alert, animated: true, completion: nil)
        }
        else{
            
            num1 = Double(firstTextNum.text!)!
            num2 = Double(secondTextNum.text!)!
            
            let sum = Double(num1 - num2)
            
            resultLabel.text = "Result : \(sum)"
            
        }
    }
    
    
    @IBAction func multiplyButton(_ sender: Any) {
        
        var num1:Double
        var num2:Double
        
        if Double(firstTextNum.text!) == nil || Double(secondTextNum.text!) == nil {
            
            let alert = UIAlertController(title: "Invalid Number", message: "Please enter a number!", preferredStyle: .alert)
            
            let action = UIAlertAction(title: "Cancel", style: .default, handler: nil)
            
            alert.addAction(action)
            
            present(alert, animated: true, completion: nil)
        }
            
        else if firstTextNum.text!.isEmpty || secondTextNum.text!.isEmpty{
            
            let alert = UIAlertController(title: "Number Needed", message: "Please enter a number!", preferredStyle: .alert)
            
            let action = UIAlertAction(title: "Cancel", style: .default, handler: nil)
            
            alert.addAction(action)
            
            present(alert, animated: true, completion: nil)
        }
        else{
            
            num1 = Double(firstTextNum.text!)!
            num2 = Double(secondTextNum.text!)!
            
            let sum = Double(num1 * num2)
            
            resultLabel.text = "Result : \(sum)"
            
        }
        
        
    }
    
    @IBAction func divideButton(_ sender: Any) {
        
        var num1:Double
        var num2:Double
        
        if Double(firstTextNum.text!) == nil || Double(secondTextNum.text!) == nil {
            
            let alert = UIAlertController(title: "Invalid Number", message: "Please enter a number!", preferredStyle: .alert)
            
            let action = UIAlertAction(title: "Cancel", style: .default, handler: nil)
            
            alert.addAction(action)
            
            present(alert, animated: true, completion: nil)
        }
            
        else if firstTextNum.text!.isEmpty || secondTextNum.text!.isEmpty{
            
            let alert = UIAlertController(title: "Number Needed", message: "Please enter a number!", preferredStyle: .alert)
            
            let action = UIAlertAction(title: "Cancel", style: .default, handler: nil)
            
            alert.addAction(action)
            
            present(alert, animated: true, completion: nil)
        }
        else{
            
            if secondTextNum.text == "0"{
                
                let alert = UIAlertController(title: "Zero Not Allowed", message: "Please enter a non zero number!", preferredStyle: .alert)
                
                let action = UIAlertAction(title: "Cancel", style: .default, handler: nil)
                
                alert.addAction(action)
            
                present(alert, animated: true, completion: nil)
                
            }
            
            num1 = Double(firstTextNum.text!)!
            num2 = Double(secondTextNum.text!)!
            
            let sum = Double(num1 / num2)
            
            resultLabel.text = "Result : \(sum)"
            
        }
        
        
    }
    
    @IBAction func clearButton(_ sender: Any) {
    
        self.firstTextNum.text = ""
        self.secondTextNum.text = ""
        
    }
    
    
}

