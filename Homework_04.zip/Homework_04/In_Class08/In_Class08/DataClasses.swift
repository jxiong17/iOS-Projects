//
//  DataClasses.swift
//  In_Class08
//
//  Created by Xiong, Jeff on 3/20/19.
//  Copyright © 2019 Xiong, Jeff. All rights reserved.
//

import Foundation
import Alamofire
import SwiftyJSON

class Weather {
    
    var temp: Int?
    var max: Int?
    var min: Int?
    var description: String?
    var humidity: Int?
    var speed: Int?
    var degree: Int?
    var cloudiness: Int?
    var cityName: String?
    var country: String?
    var date: String?
    var icon: String?
    
    
}
