//
//  CurrentWeatherViewController.swift
//  In_Class08
//
//  Created by Xiong, Jeff on 3/20/19.
//  Copyright © 2019 Xiong, Jeff. All rights reserved.
//

import UIKit
import Alamofire
import SwiftyJSON
import AlamofireImage



class CurrentWeatherViewController: UIViewController {

    
    @IBOutlet weak var weatherImage: UIImageView!
    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var tempLabel: UILabel!
    @IBOutlet weak var maxLabel: UILabel!
    @IBOutlet weak var minLabel: UILabel!
    @IBOutlet weak var descriptionLabel: UILabel!
    @IBOutlet weak var humidityLabel: UILabel!
    @IBOutlet weak var windSpeedLabel: UILabel!
    @IBOutlet weak var windDegreeLabel: UILabel!
    @IBOutlet weak var cloudinessLabel: UILabel!
    
    var weather: Weather?
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        print("this is in the current weather view controller \(String(describing: (weather!.temp)!))")

        
        titleLabel.text = "\(String(describing: (weather!.cityName)!)),  \(String(describing: (weather!.country)!))"
        tempLabel.text = "\(String(describing: (weather!.temp)!)) F"
        maxLabel.text = "\(String(describing: (weather!.max)!)) F"
        minLabel.text = "\(String(describing: (weather!.min)!)) F"
        descriptionLabel.text = weather?.description?.uppercased()
        humidityLabel.text = "\(String(describing: (weather!.humidity)!)) %"
        windSpeedLabel.text = "\(String(describing: (weather!.speed)!)) miles/hr"
        windDegreeLabel.text = "\(String(describing: (weather!.degree)!)) degrees"
        cloudinessLabel.text = "\(String(describing: (weather!.cloudiness)!)) %"

        //print(" this is the url:   http://openweathermap.org/img/w/\(weather!.icon!).png")
        
        let link = URL(string: "http://openweathermap.org/img/w/\(weather!.icon!).png")
        weatherImage.af_setImage(withURL: link!)

        
    }
    
    //prepare for segue
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        if segue.identifier == "CurrentToForecast" {
            let destinationVC = segue.destination as! ForcastViewController
            destinationVC.selectedWeather = weather
            print("This is in segue was sent")
        }
        
    }


}
