//
//  ViewController.swift
//  In_Class08
//
//  Created by Xiong, Jeff on 3/20/19.
//  Copyright © 2019 Xiong, Jeff. All rights reserved.
//

import UIKit
import Alamofire
import SwiftyJSON


class ViewController: UIViewController {

    @IBOutlet weak var locationTextField: UITextField!
    var location: String?
    let apiKey = "98bbc14250af8556bc911e34f50bc6ad"
    @IBOutlet weak var tableView: UITableView!
    var country = [String]()
    let data = AppData()
    var weather = Weather()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        
        country = Array(data.cities.keys)
        
        print(country)
    }
    
    
    // Get questions API
    func getAPI(country: String, city: String, apiKey: String) {
        
        print("this is the whole api string: https://samples.openweathermap.org/data/2.5/weather?q=\(city),\(country)&units=imperial&appid=\(apiKey)")
        
        let parameters: Parameters = ["q": "\(city),\(country)", "units": "imperial", "appid": apiKey]
        Alamofire.request("http://api.openweathermap.org/data/2.5/weather?", parameters: parameters).responseJSON { (response) in
            if response.result.isSuccess {
                
                let data = JSON(response.result.value!)
                print(data)
                let main = data["main"].dictionaryValue
                self.weather.humidity = main["humidity"]?.intValue
                self.weather.max = main["temp_max"]?.intValue
                self.weather.min = main["temp_min"]?.intValue
                self.weather.temp = main["temp"]?.intValue

                let clouds = data["clouds"].dictionaryValue
                self.weather.cloudiness = clouds["all"]?.intValue

                let weather1 = data["weather"].arrayValue
                let weather2 = weather1[0].dictionaryValue
                self.weather.description = weather2["description"]?.stringValue
                self.weather.icon = weather2["icon"]?.stringValue
                
                let wind = data["wind"].dictionaryValue
                self.weather.speed = wind["speed"]?.intValue
                self.weather.degree = wind["deg"]?.intValue
                
                print(self.weather.description!)
                self.performSegue(withIdentifier: "citiesToCurrentWeather", sender: self)
                
                self.weather.cityName = data["name"].stringValue
                
                let sys = data["sys"].dictionaryValue
                self.weather.country = sys["country"]?.stringValue
                
                
                
            }
            else {
                print("Error in JSON.request")
            }
            
        }
    }
    
    //prepare to send question list to weather to Current Weather controller
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        if segue.identifier == "citiesToCurrentWeather" {
            
            let destinationProfile = segue.destination as! CurrentWeatherViewController
            destinationProfile.weather = weather
            
            print("The prepare ran in view controller")
        }
    }


}

extension ViewController: UITableViewDataSource {
    
    //number of rows
    public func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        let city = country[section]
        return data.cities[city]!.count
    }
    
    public func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "myCell", for: indexPath)
        
        //get country string
        let newCountry = country[indexPath.section]
        //get the list of city from string country
        let cityInCountry = data.cities[newCountry]
        //get the city in array
        let city = cityInCountry![indexPath.row]
        
        cell.textLabel?.text = city
        
        return cell
    }
    
    //number of sections
    public func numberOfSections(in tableView: UITableView) -> Int {
        return country.count
    }
    
    
}

extension ViewController: UITableViewDelegate {
    
    
    func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        let country = self.country[section]
        return country
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        //replaceAll(" " ,"%20");
        //set the country and city
        let selectCountry = country[indexPath.section]
        let selectedCity = data.cities[selectCountry]![indexPath.row]
        
        print("this is the country: \(selectCountry) and the city is: \(selectedCity)")
        
        getAPI(country: selectCountry, city: selectedCity, apiKey: apiKey)
        
        
    }
    
}

