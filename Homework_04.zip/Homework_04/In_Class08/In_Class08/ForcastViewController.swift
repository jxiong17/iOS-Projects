//
//  ForcastViewController.swift
//  In_Class08
//
//  Created by Xiong, Jeff on 3/24/19.
//  Copyright © 2019 Xiong, Jeff. All rights reserved.
//

import UIKit
import Alamofire
import SwiftyJSON
import AlamofireImage

class ForcastViewController: UIViewController {
    
   
    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var tableView: UITableView!
    var selectedWeather: Weather?
    var forecastWeather = [Weather]()
    var city: String?
    var country: String?
    let apiKey = "98bbc14250af8556bc911e34f50bc6ad"
    

    override func viewDidLoad() {
        super.viewDidLoad()

        //set title
        self.title = "Weather Forecast"
        
        //get city and country
        self.city = selectedWeather!.cityName!
        self.country = selectedWeather!.country!
        
        self.titleLabel.text = "\(selectedWeather!.cityName!),  \(selectedWeather!.country!)"
            
        print("The count of objects in forecast: \(forecastWeather.count)")
        
        tableView.reloadData()
        
    }
    
    override func viewWillAppear(_ animated: Bool) {
        
        //call method to get forecast
        getAPI(country: country!, city: city!, apiKey: apiKey)
        
        tableView.reloadData()
    }
    
    // Get questions API
    func getAPI(country: String, city: String, apiKey: String) {
        
        print("this is the whole api string: https://api.openweathermap.org/data/2.5/forecast?q=\(city),\(country)&units=imperial&appid=\(apiKey)")
        
        let parameters: Parameters = ["q": "\(city),\(country)", "units": "imperial", "appid": apiKey]
        Alamofire.request("http://api.openweathermap.org/data/2.5/forecast?", parameters: parameters).responseJSON { (response) in
            if response.result.isSuccess {
                
                let data = JSON(response.result.value!)
                //print(data)
                let list = data["list"].arrayValue
                //print(list[0])

                for i in 0...list.count-1 {
                    
                    //create object weather
                    let weather = Weather()
    
                    print(i)
                    print(list[i])
                    let main = list[i]["main"].dictionaryValue
                    
                    weather.humidity = main["humidity"]?.intValue
                    print(main["humidity"]?.intValue as Any)
                    weather.max = main["temp_max"]?.intValue
                    weather.min = main["temp_min"]?.intValue
                    weather.temp = main["temp"]?.intValue
                    
    
                    let weather1 = list[i]["weather"].arrayValue
                    let weather2 = weather1[0].dictionaryValue
                    weather.description = weather2["description"]?.stringValue
                    weather.icon = weather2["icon"]?.stringValue
                    
                    let dt_txt = list[i]["dt_txt"].stringValue
                    weather.date = dt_txt
                    
                    
                    print(weather)
                
                    //add weather to forecast
                    self.forecastWeather.append(weather)
                    
                    print("This is the count of objects in forecastweather: \(self.forecastWeather.count)")
                    self.tableView.reloadData()
                }
            }
            else {
                print("Error in JSON.request")
            }
        }
    }
    


}//end of ForecastViewController


extension ForcastViewController: UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return forecastWeather.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        //create cell
        let cell = tableView.dequeueReusableCell(withIdentifier: "forecastCell", for: indexPath)
        
        //create labels by tags
        let tempLabel = cell.viewWithTag(100) as! UILabel
        let humidLabel  = cell.viewWithTag(400) as! UILabel
        let maxLabel  = cell.viewWithTag(200) as! UILabel
        let minLabel  = cell.viewWithTag(300) as! UILabel
        let descripLabel  = cell.viewWithTag(500) as! UILabel
        let timeLabel  = cell.viewWithTag(600) as! UILabel
        let weatherImage = cell.viewWithTag(700) as! UIImageView

        tempLabel.text = "\(forecastWeather[indexPath.row].temp!) F"
        humidLabel.text = "\(forecastWeather[indexPath.row].humidity!) %"
        maxLabel.text = "Max: \(forecastWeather[indexPath.row].max!) F"
        minLabel.text = "Min: \(forecastWeather[indexPath.row].min!) F"
        descripLabel.text = forecastWeather[indexPath.row].description?.uppercased()
        timeLabel.text = forecastWeather[indexPath.row].date
        
        //image
        let link = URL(string: "http://openweathermap.org/img/w/\(forecastWeather[indexPath.row].icon!).png")
        weatherImage.af_setImage(withURL: link!)
        
        return cell
    }
  
}

extension ForcastViewController: UITabBarDelegate {

    
}
