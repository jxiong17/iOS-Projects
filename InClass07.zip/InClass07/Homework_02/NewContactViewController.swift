//
//  NewContactViewController.swift
//  Homework_02
//
//  Created by Xiong, Jeff on 2/17/19.
//  Copyright © 2019 Xiong, Jeff. All rights reserved.
//

import UIKit

class NewContactViewController: UIViewController {

    
    @IBOutlet weak var nameTextField: UITextField!
    @IBOutlet weak var emailTextField: UITextField!
    @IBOutlet weak var phoneNumberTextField: UITextField!
    @IBOutlet weak var phoneTypeSegController: UISegmentedControl!
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    
    //prepare for segue
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {

        let destinationContacts = segue.destination as! ViewController
        let name = self.nameTextField.text
        let email = self.emailTextField.text
        let phoneNumber = self.phoneNumberTextField.text
        let phoneType: String

        switch phoneTypeSegController.selectedSegmentIndex {
        case 0:
            phoneType = "CELL"
        case 1:
            phoneType = "HOME"
        case 2:
            phoneType = "OFFICE"
        default:
            phoneType = "Error"
        }
    
        print("This is in the prepare \(name!), \(email!), \(phoneNumber!), \(phoneType)")
        
        destinationContacts.newContact = [name!, email!, phoneNumber!, phoneType]
        
    }
    
    //cancel button
    @IBAction func cancelClicked(_ sender: Any) {
        dismiss(animated: true, completion: nil)
    }
    
    //submit button
    @IBAction func submitClicked(_ sender: Any) {
        performSegue(withIdentifier: "newContactToContacts", sender: self)
    }
    
    //check empty textfields
    override func shouldPerformSegue(withIdentifier identifier: String, sender: Any?) -> Bool {
        
        print("this is in the shouldpreform")
        
        if self.nameTextField.text == "" || self.emailTextField.text == "" || self.phoneNumberTextField.text == ""{
            let alert = UIAlertController(title: "Error", message: "Please Enter All Infomation", preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
            self.present(alert, animated: true, completion: nil)
            return false
        }
        else{
            return true
        }
    }
    

}
