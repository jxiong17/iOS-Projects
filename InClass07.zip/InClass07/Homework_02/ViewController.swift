//
//  ViewController.swift
//  Homework_02
//
//  Created by Xiong, Jeff on 2/17/19.
//  Copyright © 2019 Xiong, Jeff. All rights reserved.
//

//variable contact number
var contactNumber: Int?

import UIKit
import Alamofire

class ViewController: UIViewController {

    
    //array of contacts
    var listOfContacts = [Contact]()
    
    //create variable contactSelected
    var contactSelected: Int?
    
    //array of strings to create new contact
    var newContact: [String]?
   
    //create object contact
    var updatedContact: Contact?
    
    @IBOutlet weak var tableView: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.refreshTable()
        
        //register custom cell
        let cellNIb = UINib(nibName: "MyCustomTableViewCell", bundle: nil)
        tableView.register(cellNIb, forCellReuseIdentifier: "newCell")
        
        print("viewDidLoad")
        
    }
    
    
    //prepare to send object contact selected to detials
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        if segue.identifier == "contactsToDetails" {
            
            let destinationProfile = segue.destination as! DetailsViewController
            destinationProfile.selectedContact = listOfContacts[contactSelected!]
        
        }
    }

    
    //first unwind adding new contact
    @IBAction func myUnwindAction(unwindSegue: UIStoryboardSegue){
        
        print("UnwindedSegue ran")
        
        // Create Contact API
        let parameters: Parameters = ["name": newContact![0], "email": newContact![1], "phone": newContact![2], "type": newContact![3]]
        AF.request("http://ec2-18-234-222-229.compute-1.amazonaws.com/contact/create", method: .post, parameters: parameters, encoding: URLEncoding.default, headers: nil, interceptor: nil).responseString { (response) in
            if response.result.isSuccess {
                self.refreshTable()
            } else {
                print("Error in AF.request")
            }
        }
        
    }
    
    
    //second unwind deleting in details
    @IBAction func mySecondUnwindAction(unwindSegue: UIStoryboardSegue){


        print("count of contacts in my secondUnwindAction \(listOfContacts.count)")

        print(contactNumber!)
        
        let contactToRemove = listOfContacts[contactNumber!]
        
        // Delete Contact API
        let parameters: Parameters = ["id": contactToRemove.id]
        AF.request("http://ec2-18-234-222-229.compute-1.amazonaws.com/contact/delete", method: .post, parameters: parameters, encoding: URLEncoding.default, headers: nil, interceptor: nil).responseString { (response) in
            if response.result.isSuccess {
                print("Deleted contact with id \(contactToRemove.id)")
                self.refreshTable()
            } else {
                print("Error in AF.request")
            }
        }
    }
    
    //third unwind for editviewcontroller
    @IBAction func mythirdUnwindAction(unwindSegue: UIStoryboardSegue){
        
        
        print("count of contacts in my thirdUnwindAction \(listOfContacts.count)")
        
        print(contactNumber!)
        
//        listOfContacts[contactNumber!] = updatedContact!
        print(updatedContact!.name)
        
        // Update Contact API
        let parameters: Parameters = ["id": updatedContact!.id,"name": updatedContact!.name, "email": updatedContact!.email, "phone": updatedContact!.phoneNumber, "type": updatedContact!.phoneType]
        AF.request("http://ec2-18-234-222-229.compute-1.amazonaws.com/contact/update", method: .post, parameters: parameters, encoding: URLEncoding.default, headers: nil, interceptor: nil).responseString { (response) in
            if response.result.isSuccess {
                print("Updated contact with id \(self.updatedContact!.id)")
                self.refreshTable()
            } else {
                print("Error in AF.request")
            }
        }
        
    }
    
    // refresh table using Get Contacts API
    func refreshTable() {
        AF.request("http://ec2-18-234-222-229.compute-1.amazonaws.com/contacts").responseString { (response) in
            if response.result.isSuccess {
                let responseString = response.result.value!
                let responseContacts = responseString.split(separator: "\n")
                self.listOfContacts = []
                for contactString in responseContacts {
                    let contactData = contactString.split(separator: ",")
                    self.listOfContacts.append(Contact(String(contactData[1]), String(contactData[2]), String(contactData[3]), String(contactData[4]), Int(contactData[0]) ?? -1))
                }
                self.tableView.reloadData()
                
            } else {
                print("Error in AF.request")
            }
        }
    }
    

}


//Table View Cell Layout
extension ViewController: UITableViewDataSource {
    
    //return number of rows to show
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        print("the list of contacts in the beginning \(listOfContacts.count)")
        return listOfContacts.count
        
    }
    
    //return list of contacts data in each cell
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "newCell", for: indexPath) as! MyCustomTableViewCell
        let contact = listOfContacts[indexPath.row]
        
        //set labels with data
        cell.nameCellLabel.text = contact.name
        cell.emailCellLabel.text = contact.email
        cell.phoneNumberCellLabel.text = contact.phoneNumber
        cell.phoneTypeCellLabel.text = "(" + contact.phoneType + ")"
        
        cell.delegate = self
        
        return cell
        
    }
    
}


//determind number of rows
extension ViewController: UITableViewDelegate {
    
    //determind with row was selected
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        print("This row \(indexPath.row) is selected with Name of \(listOfContacts[indexPath.row].name)")
        contactSelected = indexPath.row

        contactNumber = indexPath.row
        contactSelected = indexPath.row
        
        //performSegue
        performSegue(withIdentifier: "contactsToDetails", sender:  self)

    }
    
}

//interface
extension ViewController: CustomTVCellDelegate {
    
    func delete(cell: UITableViewCell) {
        
        //delete cell 
        let indexPath = self.tableView.indexPath(for: cell)
        let contactToRemove = listOfContacts[indexPath![1]]
        
        // Delete Contact API
        let parameters: Parameters = ["id": contactToRemove.id]
        AF.request("http://ec2-18-234-222-229.compute-1.amazonaws.com/contact/delete", method: .post, parameters: parameters, encoding: URLEncoding.default, headers: nil, interceptor: nil).responseString { (response) in
            if response.result.isSuccess {
                print("Deleted contact with id \(contactToRemove.id)")
                self.refreshTable()
            } else {
                print("Error in AF.request")
            }
        }
        
        print("this is the indexpath \(indexPath![1])")
        
    }

}

//creating a contact class
class Contact {
        
    var name:String
    var email:String
    var phoneNumber:String
    var phoneType:String
    var id:Int

    init (_ name: String, _ email: String, _ phoneNumber: String, _ phoneType: String, _ id: Int) {
        
        self.name = name
        self.email = email
        self.phoneNumber = phoneNumber
        self.phoneType = phoneType
        self.id = id
    }
        
}
