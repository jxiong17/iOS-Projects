//
//  EditViewController.swift
//  Homework_02
//
//  Created by Xiong, Jeff on 2/19/19.
//  Copyright © 2019 Xiong, Jeff. All rights reserved.
//

import UIKit

class EditViewController: UIViewController {

    //create object contact
    var selectedContact:Contact?
    
    
    @IBOutlet weak var nameTextField: UITextField!
    @IBOutlet weak var emailTextField: UITextField!
    @IBOutlet weak var phoneNumberTextField: UITextField!
    @IBOutlet weak var phoneTypeSegmentedControl: UISegmentedControl!
    var phoneType: String?
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        print(selectedContact!.name)
        
        self.nameTextField.text = selectedContact!.name
        self.emailTextField.text = selectedContact!.email
        self.phoneNumberTextField.text = selectedContact!.phoneNumber
        
        switch selectedContact!.phoneType {
            case "CELL":
                self.phoneTypeSegmentedControl.selectedSegmentIndex = 0
            case "HOME":
                self.phoneTypeSegmentedControl.selectedSegmentIndex = 1
            case "OFFICE":
                self.phoneTypeSegmentedControl.selectedSegmentIndex = 2
            default:
                print("there is an error")
        }
        
    
    }
    
    //for updatebutton Clicked
    @IBAction func updateButtonClicked(_ sender: Any) {

        navigationController?.popToRootViewController(animated: true)
        
    }
    
    //prepare to send object to Viewcontrol
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        switch phoneTypeSegmentedControl.selectedSegmentIndex {
        case 0:
            phoneType = "CELL"
        case 1:
            phoneType = "HOME"
        case 2:
            phoneType = "OFFICE"
        default:
            print("Error")
        }
        
        print("This was in update button \(self.nameTextField.text)")
        
        selectedContact = Contact(self.nameTextField.text!, self.emailTextField.text!, self.phoneNumberTextField.text!, phoneType!, selectedContact!.id)
        
        let destinationProfile = segue.destination as! ViewController
        destinationProfile.updatedContact = self.selectedContact
        print("prepare ran for edit view")
        
    }
    

    //checks for empty fields
    override func shouldPerformSegue(withIdentifier identifier: String, sender: Any?) -> Bool {
        
        print("this is in the shouldpreform")
        
        if self.nameTextField.text == "" || self.emailTextField.text == "" || self.phoneNumberTextField.text == ""{
            let alert = UIAlertController(title: "Error", message: "Please Enter All Infomation", preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
            self.present(alert, animated: true, completion: nil)
            return false
        }
        else{
            return true
        }
    }
    

}
