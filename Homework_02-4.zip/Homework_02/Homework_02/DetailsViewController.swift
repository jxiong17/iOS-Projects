//
//  DetailsViewController.swift
//  Homework_02
//
//  Created by Xiong, Jeff on 2/17/19.
//  Copyright © 2019 Xiong, Jeff. All rights reserved.
//

import UIKit

class DetailsViewController: UIViewController {

    //created object
    var selectedContact:Contact?
    
    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var emailLabel: UILabel!
    @IBOutlet weak var phoneNumberLabel: UILabel!
    @IBOutlet weak var phoneTypeLabel: UILabel!
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        //assign label with data that was sent from contact view
        self.nameLabel.text = selectedContact?.name
        self.emailLabel.text = selectedContact?.email
        self.phoneNumberLabel.text = selectedContact?.phoneNumber
        self.phoneTypeLabel.text = selectedContact?.phoneType
        
    }
    

    
    //prepare to send object contact selected
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        if segue.identifier == "DetailsToEdit" {
            
            let destinationProfile = segue.destination as! EditViewController
            destinationProfile.selectedContact = self.selectedContact
            
        }
    }
    
    //delete button
    @IBAction func deleteButtonClicked(_ sender: Any) {
        
        navigationController?.popToRootViewController(animated: true)
        
    }
    
    
    
}
