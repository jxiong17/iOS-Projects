//
//  ViewController.swift
//  Homework_02
//
//  Created by Xiong, Jeff on 2/17/19.
//  Copyright © 2019 Xiong, Jeff. All rights reserved.
//

//variable contact number
var contactNumber: Int?

import UIKit

class ViewController: UIViewController {

    
    //array of contacts
    var listOfContacts = [Contact]()
    
    //create variable contactSelected
    var contactSelected: Int?
    
    //array of strings to create new contact
    var newContact: [String]?
   
    //create object contact
    var updatedContact: Contact?
    
    @IBOutlet weak var tableView: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        //create contacts in listofcontacts
        listOfContacts.append(Contact("Jeff Xiong", "jeffxiong@uncc.edu", "7045555555", "Cell"))
        listOfContacts.append(Contact("Marvin Yang", "marvinyang@uncc.edu", "7042225555", "Home"))
        listOfContacts.append(Contact("Bob Smith", "bobsmith@uncc.edu", "7043335555", "Office"))
        listOfContacts.append(Contact("Jane Doe", "janedoe@uncc.edu", "704445555", "Cell"))
        
        //register custom cell
        let cellNIb = UINib(nibName: "MyCustomTableViewCell", bundle: nil)
        tableView.register(cellNIb, forCellReuseIdentifier: "newCell")
        
        print("viewDidLoad")
        
    }
    
    
    //prepare to send object contact selected to detials
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        if segue.identifier == "contactsToDetails" {
            
            let destinationProfile = segue.destination as! DetailsViewController
            destinationProfile.selectedContact = listOfContacts[contactSelected!]
        
        }
    }

    
    //first unwind adding new contact
    @IBAction func myUnwindAction(unwindSegue: UIStoryboardSegue){
        
        print("UnwindedSegue ran")
        
        listOfContacts.append(Contact(newContact![0], newContact![1], newContact![2], newContact![3]))
        
        tableView.reloadData()
        
    }
    
    
    //second unwind deleting in details
    @IBAction func mySecondUnwindAction(unwindSegue: UIStoryboardSegue){


        print("count of contacts in my secondUnwindAction \(listOfContacts.count)")

        print(contactNumber!)
        
        listOfContacts.remove(at: contactNumber!)
        
        tableView.reloadData()
    }
    
    //third unwind for editviewcontroller
    @IBAction func mythirdUnwindAction(unwindSegue: UIStoryboardSegue){
        
        
        print("count of contacts in my thirdUnwindAction \(listOfContacts.count)")
        
        print(contactNumber!)
        
        listOfContacts[contactNumber!] = updatedContact!
        print(updatedContact!.name)
        tableView.reloadData()
    }
    

}


//Table View Cell Layout
extension ViewController: UITableViewDataSource {
    
    //return number of rows to show
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        print("the list of contacts in the beginning \(listOfContacts.count)")
        return listOfContacts.count
        
    }
    
    //return list of contacts data in each cell
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "newCell", for: indexPath) as! MyCustomTableViewCell
        let contact = listOfContacts[indexPath.row]
        
        //set labels with data
        cell.nameCellLabel.text = contact.name
        cell.emailCellLabel.text = contact.email
        cell.phoneNumberCellLabel.text = contact.phoneNumber
        cell.phoneTypeCellLabel.text = "(" + contact.phoneType + ")"
        
        cell.delegate = self
        
        return cell
        
    }
    
}


//determind number of rows
extension ViewController: UITableViewDelegate {
    
    //determind with row was selected
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        print("This row \(indexPath.row) is selected with Name of \(listOfContacts[indexPath.row].name)")
        contactSelected = indexPath.row

        contactNumber = indexPath.row
        contactSelected = indexPath.row
        
        //performSegue
        performSegue(withIdentifier: "contactsToDetails", sender:  self)

    }
    
}

//interface
extension ViewController: CustomTVCellDelegate {
    
    func delete(cell: UITableViewCell) {
        
        //delete cell 
        let indexPath = self.tableView.indexPath(for: cell)
        listOfContacts.remove(at: indexPath![1])
        tableView.reloadData()
        
        
        print("this is the indexpath \(indexPath![1])")
        
    }

}

//creating a contact class
class Contact {
        
    var name:String
    var email:String
    var phoneNumber:String
    var phoneType:String
    

    init (_ name: String, _ email: String, _ phoneNumber: String, _ phoneType: String) {
        
        self.name = name
        self.email = email
        self.phoneNumber = phoneNumber
        self.phoneType = phoneType
    }
        
}
