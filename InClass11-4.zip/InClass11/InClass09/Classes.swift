//
//  Classes.swift
//  InClass09
//
//  Created by Xiong, Jeff on 4/15/19.
//  Copyright © 2019 UNCC. All rights reserved.
//

import Foundation
import Firebase
import FirebaseDatabase
import FirebaseStorage

class Photo {
    
    var photoURL: URL?
    var key: String?
    var photoRefKey: String?
    var placement: Int?
    
}
